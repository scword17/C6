CREATE PROCEDURE p_2()
  begin

select * from user order by id desc;

end;

